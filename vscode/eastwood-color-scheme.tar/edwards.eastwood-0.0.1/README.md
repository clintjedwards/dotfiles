Clint Edwards custom vscode theme
